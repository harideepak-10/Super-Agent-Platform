import os
from django.core.asgi import get_asgi_application
from channels.routing import ProtocolTypeRouter, URLRouter

os.environ.setdefault("DJANGO_SETTINGS_MODULE", "superagent.settings.development")

django_asgi_app = get_asgi_application()

from apps.websockets.routing import websocket_urlpatterns  # noqa: E402
from apps.websockets.middleware import JWTAuthMiddleware   # noqa: E402

application = ProtocolTypeRouter({
    "http": django_asgi_app,
    "websocket": JWTAuthMiddleware(
        URLRouter(websocket_urlpatterns)
    ),
})
